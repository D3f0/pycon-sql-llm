# PyCon Kenya 2025 - LLMs for SQL
